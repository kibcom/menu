<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';

$menuCode = trim($_GET['id'] ?? '');
if ($menuCode === '') {
    http_response_code(404);
    exit('Menu not found.');
}

$menuStmt = $pdo->prepare('SELECT * FROM menus WHERE menu_code = ? LIMIT 1');
$menuStmt->execute([$menuCode]);
$menu = $menuStmt->fetch();

if (!$menu) {
    http_response_code(404);
    exit('Menu not found.');
}

$pdo->prepare('UPDATE menus SET views = views + 1 WHERE id = ?')->execute([$menu['id']]);

$catStmt = $pdo->prepare('SELECT * FROM categories WHERE menu_id = ? ORDER BY sort_order ASC, id ASC');
$catStmt->execute([$menu['id']]);
$categories = $catStmt->fetchAll();

$itemStmt = $pdo->prepare('SELECT * FROM items WHERE menu_id = ? AND is_visible = 1 ORDER BY sort_order ASC, id ASC');
$itemStmt->execute([$menu['id']]);
$allItems = $itemStmt->fetchAll();

$itemsByCategory = [];
foreach ($allItems as $item) {
    $itemsByCategory[$item['category_id']][] = $item;
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($menu['name']) ?> - Menu</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="page-menu">
    <header class="topbar">
        <div class="container topbar-inner">
            <div class="topbar-brand">
                <?php if (!empty($menu['logo_image'])): ?>
                    <img class="topbar-logo" src="<?= e($menu['logo_image']) ?>" alt="" width="40" height="40" decoding="async">
                <?php endif; ?>
                <strong class="topbar-title"><?= e($menu['name']) ?></strong>
            </div>
            <button id="shareBtn" class="btn btn-outline" type="button">Share</button>
        </div>
    </header>

    <section class="hero hero--edge hero--menu hero--brand-only" aria-label="Menu">
        <div class="container hero-brand-inner">
            <div class="hero-brand-row<?= empty($menu['logo_image']) ? ' hero-brand-row--text-only' : '' ?>">
                <?php if (!empty($menu['logo_image'])): ?>
                    <img class="hero-logo-simple" src="<?= e($menu['logo_image']) ?>" alt="<?= e($menu['name']) ?> logo" width="88" height="88">
                <?php endif; ?>
                <div class="hero-text-block">
                    <span class="hero-eyebrow hero-eyebrow--on-gradient">Menu</span>
                    <h1 class="hero-title hero-title--on-gradient"><?= e($menu['name']) ?></h1>
                    <p class="hero-tagline hero-tagline--on-gradient"><?= e((string) ($menu['description'] ?? 'Explore our menu items.')) ?></p>
                </div>
            </div>
        </div>
    </section>

    <main class="container">
        <div class="menu-sticky-wrap">
            <div class="menu-filters menu-filters--toolbar" aria-label="Search and filter menu">
                <p class="filter-rail-label">Browse &amp; search</p>
                <div class="filter-rail" role="group" aria-label="Search and categories">
                    <label class="search-pill" title="Search menu">
                        <span class="search-pill__icon" aria-hidden="true"></span>
                        <input
                            id="searchInput"
                            class="search-pill__input"
                            type="search"
                            inputmode="search"
                            autocomplete="off"
                            placeholder="Search…"
                            aria-label="Search menu"
                        >
                    </label>
                    <div class="filter-rail__tablist" role="tablist" aria-label="Jump to category">
                        <button type="button" class="cat-pill is-active" data-category="all" data-target="menuListTop" role="tab" aria-selected="true">All</button>
                        <?php foreach ($categories as $cat): ?>
                            <button
                                type="button"
                                class="cat-pill"
                                data-category="<?= (int) $cat['id'] ?>"
                                data-target="cat-<?= (int) $cat['id'] ?>"
                                role="tab"
                                aria-selected="false"
                            ><?= e($cat['name']) ?></button>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>

        <div id="menuListTop" class="menu-list-top" aria-hidden="true"></div>

        <?php foreach ($categories as $cat): ?>
            <section id="cat-<?= (int) $cat['id'] ?>" class="category-block" data-category-section="<?= (int) $cat['id'] ?>" data-category-title="<?= e($cat['name']) ?>">
                <h3 class="category-title"><?= e($cat['name']) ?></h3>
                <div class="items-grid">
                    <?php foreach ($itemsByCategory[$cat['id']] ?? [] as $item): ?>
                        <?php
                        $itemImg = !empty($item['image']) ? $item['image'] : 'assets/images/placeholder.svg';
                        ?>
                        <article
                            class="item-card"
                            tabindex="0"
                            data-category="<?= (int) $cat['id'] ?>"
                            data-name="<?= e($item['name']) ?>"
                            data-description="<?= e((string) $item['description']) ?>"
                            data-price-display="<?= e(formatPriceEtb($item['price'])) ?>"
                            data-item-image="<?= e($itemImg) ?>"
                        >
                            <img class="menu-image" loading="lazy" src="<?= e($itemImg) ?>" alt="" role="presentation">
                            <div>
                                <h4 style="margin:2px 0 6px;"><?= e($item['name']) ?></h4>
                                <p class="muted" style="margin:0 0 8px;"><?= e((string) $item['description']) ?></p>
                                <span class="price"><?= e(formatPriceEtb($item['price'])) ?></span>
                            </div>
                        </article>
                    <?php endforeach; ?>
                </div>
            </section>
        <?php endforeach; ?>
        <div id="noResults" class="no-results">No matching items found. Try another keyword or category.</div>
    </main>

    <div id="itemModal" class="item-modal" aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="itemModalTitle">
        <div class="image-modal__toolbar">
            <button id="itemModalBack" class="image-modal-back" type="button">← Back to menu</button>
            <button id="itemModalClose" class="image-modal-close" type="button" aria-label="Close details">&times;</button>
        </div>
        <div class="item-modal__stage" id="itemModalStage">
            <div class="item-modal__panel">
                <div class="item-modal__media">
                    <img id="itemModalImg" class="item-modal__img" src="" alt="">
                </div>
                <div class="item-modal__info">
                    <h2 id="itemModalTitle" class="item-modal__title"></h2>
                    <p id="itemModalDesc" class="item-modal__desc muted"></p>
                    <p id="itemModalPrice" class="item-modal__price price"></p>
                </div>
            </div>
        </div>
    </div>

    <div id="shareSheet" class="share-sheet" aria-hidden="true">
        <div class="share-sheet__backdrop" id="shareSheetBackdrop"></div>
        <div class="share-sheet__panel" role="dialog" aria-modal="true" aria-labelledby="shareSheetTitle">
            <div class="share-sheet__grab" aria-hidden="true"></div>
            <div class="share-sheet__header">
                <h2 id="shareSheetTitle" class="share-sheet__title">Share this menu</h2>
                <button type="button" class="share-sheet__x" id="shareSheetClose" aria-label="Close">&times;</button>
            </div>
            <p class="share-sheet__copied" id="shareSheetCopied">Link copied!</p>
            <p class="share-sheet__sub">Send it on:</p>
            <ul class="share-sheet__list">
                <li>
                    <a id="shareLinkWhatsApp" class="share-sheet__link" href="#" target="_blank" rel="noopener noreferrer">
                        <span class="share-sheet__ico" aria-hidden="true">💬</span>
                        <span>WhatsApp</span>
                    </a>
                </li>
                <li>
                    <a id="shareLinkFacebook" class="share-sheet__link" href="#" target="_blank" rel="noopener noreferrer">
                        <span class="share-sheet__ico" aria-hidden="true">📘</span>
                        <span>Facebook</span>
                    </a>
                </li>
                <li>
                    <a id="shareLinkX" class="share-sheet__link" href="#" target="_blank" rel="noopener noreferrer">
                        <span class="share-sheet__ico" aria-hidden="true">𝕏</span>
                        <span>X (Twitter)</span>
                    </a>
                </li>
                <li>
                    <a id="shareLinkTelegram" class="share-sheet__link" href="#" target="_blank" rel="noopener noreferrer">
                        <span class="share-sheet__ico" aria-hidden="true">✈️</span>
                        <span>Telegram</span>
                    </a>
                </li>
                <li>
                    <a id="shareLinkEmail" class="share-sheet__link" href="#">
                        <span class="share-sheet__ico" aria-hidden="true">✉️</span>
                        <span>Email</span>
                    </a>
                </li>
            </ul>
            <button type="button" class="share-sheet__native btn" id="shareNativeBtn">Share using device…</button>
            <button type="button" class="share-sheet__copyagain btn btn-outline" id="shareCopyAgain">Copy link again</button>
        </div>
    </div>

    <script src="assets/js/menu.js"></script>
</body>
</html>
