<?php
declare(strict_types=1);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Foodie QR Menu</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="landing-page">
    <div class="landing-wrap">
        <section class="container landing-hero">
            <div class="landing-hero__content">
                <p class="landing-kicker">Smart Restaurant Experience</p>
                <h1 class="landing-title">Turn every table into a digital foodie menu</h1>
                <p class="landing-subtitle">
                    Beautiful mobile menu pages, fast QR access, and simple admin tools for your restaurant team.
                </p>
                <div class="landing-cta-row">
                    <a class="btn landing-btn" href="admin/login.php">Open Admin Panel</a>
                    <a class="btn btn-outline landing-btn-outline" href="menu.php?id=demo2026">View Demo Menu</a>
                </div>
                <div class="landing-metrics">
                    <div class="landing-metric">
                        <strong>Fast Setup</strong>
                        <span>Ready in minutes</span>
                    </div>
                    <div class="landing-metric">
                        <strong>QR Access</strong>
                        <span>Scan and order instantly</span>
                    </div>
                    <div class="landing-metric">
                        <strong>Modern UI</strong>
                        <span>Mobile-first design</span>
                    </div>
                </div>
            </div>
            <div class="landing-hero__visual" aria-hidden="true">
                <div class="dish-card dish-card--main">
                    <div class="dish-emoji">🍽️</div>
                    <h3>Chef's Special</h3>
                    <p>Signature dishes with rich visuals and clear prices.</p>
                </div>
                <div class="dish-card dish-card--float">
                    <div class="dish-emoji">🥗</div>
                    <p>Fresh • Colorful • Delicious</p>
                </div>
            </div>
        </section>

        <section class="container landing-features">
            <article class="landing-feature-card">
                <h3>Menu Management</h3>
                <p>Create menus, categories, and items from one clean admin panel.</p>
            </article>
            <article class="landing-feature-card">
                <h3>Instant QR Sharing</h3>
                <p>Generate and download QR codes for tables, posters, and takeaway packs.</p>
            </article>
            <article class="landing-feature-card">
                <h3>Designed for Guests</h3>
                <p>Search, filter, and item previews make ordering easy on any phone.</p>
            </article>
        </section>
    </div>
</body>
</html>
