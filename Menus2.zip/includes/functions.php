<?php
declare(strict_types=1);

require_once __DIR__ . '/../libs/phpqrcode/qrlib.php';

function e(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

function baseUrl(): string
{
    $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (isset($_SERVER['SERVER_PORT']) && (int) $_SERVER['SERVER_PORT'] === 443);
    $scheme = $isHttps ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $path = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '')), '/');
    $root = preg_replace('#/admin$#', '', $path);
    return $scheme . '://' . $host . ($root === '' ? '' : $root);
}

function randomSlug(int $length = 10): string
{
    $chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    $result = '';
    for ($i = 0; $i < $length; $i++) {
        $result .= $chars[random_int(0, strlen($chars) - 1)];
    }
    return $result;
}

function uploadImage(array $file, string $folder): ?string
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        return null;
    }

    $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'];
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    if (!isset($allowed[$mime])) {
        return null;
    }

    if ((int) $file['size'] > 5 * 1024 * 1024) {
        return null;
    }

    $ext = $allowed[$mime];
    $filename = date('YmdHis') . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    $targetDir = __DIR__ . '/../uploads/' . trim($folder, '/');
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0775, true);
    }

    $targetPath = $targetDir . '/' . $filename;
    if (!move_uploaded_file($file['tmp_name'], $targetPath)) {
        return null;
    }

    return 'uploads/' . trim($folder, '/') . '/' . $filename;
}

function generateMenuQr(string $menuCode): ?string
{
    $fullUrl = baseUrl() . '/menu.php?id=' . urlencode($menuCode);
    $dir = __DIR__ . '/../qrcodes';
    if (!is_dir($dir)) {
        mkdir($dir, 0775, true);
    }

    $filename = 'qr_' . $menuCode . '.png';
    $path = $dir . '/' . $filename;
    $ok = QRcode::png($fullUrl, $path, 'M', 8, 2);
    return $ok ? 'qrcodes/' . $filename : null;
}

function formatPrice($price): string
{
    return number_format((float) $price, 2, '.', '');
}

/** Formatted amount with thousands separators + ETB (Ethiopian Birr). */
function formatPriceEtb($price): string
{
    return number_format((float) $price, 2, '.', ',') . ' ETB';
}

function safeDeleteUpload(?string $relativePath): void
{
    if ($relativePath === null || $relativePath === '') {
        return;
    }
    $relativePath = str_replace('\\', '/', $relativePath);
    if (strpos($relativePath, '..') !== false) {
        return;
    }
    $base = realpath(__DIR__ . '/..');
    if ($base === false) {
        return;
    }
    $full = realpath($base . '/' . $relativePath);
    if ($full !== false && strpos($full, $base) === 0 && is_file($full)) {
        @unlink($full);
    }
}
