document.addEventListener('DOMContentLoaded', function () {
    const searchInput = document.getElementById('searchInput');
    const catPills = document.querySelectorAll('.cat-pill[data-category]');
    const items = document.querySelectorAll('.item-card');
    const noResults = document.getElementById('noResults');
    const categorySections = document.querySelectorAll('[data-category-section]');

    function applyFilter() {
        const q = (searchInput ? searchInput.value : '').trim().toLowerCase();
        let visibleCount = 0;
        const categoryTitleMatchMap = {};

        categorySections.forEach((section) => {
            const sectionCategory = section.dataset.categorySection || '';
            const sectionTitle = (section.dataset.categoryTitle || '').toLowerCase();
            categoryTitleMatchMap[sectionCategory] = q !== '' && sectionTitle.includes(q);
        });

        items.forEach((item) => {
            const itemCategory = item.dataset.category || '';
            const itemName = (item.dataset.name || '').toLowerCase();
            const itemDesc = (item.dataset.description || '').toLowerCase();
            const titleMatch = !!categoryTitleMatchMap[itemCategory];
            const bySearch = q === '' || titleMatch || itemName.includes(q) || itemDesc.includes(q);
            item.style.display = bySearch ? 'grid' : 'none';
            if (bySearch) {
                visibleCount += 1;
            }
        });

        categorySections.forEach((section) => {
            const sectionItems = section.querySelectorAll('.item-card');
            let sectionHasVisible = false;

            sectionItems.forEach((it) => {
                if (it.style.display !== 'none') {
                    sectionHasVisible = true;
                }
            });

            section.style.display = sectionHasVisible ? '' : 'none';
        });

        if (noResults) {
            noResults.style.display = visibleCount === 0 ? 'block' : 'none';
        }

        syncFilterPillsToScroll();
    }

    if (searchInput) {
        searchInput.addEventListener('input', applyFilter);
    }

    function getStickyBottomY() {
        const wrap = document.querySelector('.menu-sticky-wrap');
        if (wrap) {
            return wrap.getBoundingClientRect().bottom;
        }
        const tb = document.querySelector('.topbar');
        return tb ? tb.getBoundingClientRect().bottom : 72;
    }

    let lastActiveScrollCategory = null;
    let suppressScrollSpyUntil = 0;

    function syncFilterPillsToScroll() {
        if (!catPills.length) return;
        if (Date.now() < suppressScrollSpyUntil) return;

        const threshold = getStickyBottomY() + 12;
        let active = 'all';
        let anyVisible = false;

        categorySections.forEach(function (section) {
            if (section.style.display === 'none') return;
            anyVisible = true;
            const top = section.getBoundingClientRect().top;
            if (top <= threshold) {
                active = section.dataset.categorySection || 'all';
            }
        });

        if (!anyVisible) {
            active = 'all';
        }

        if (active === lastActiveScrollCategory) return;
        lastActiveScrollCategory = active;

        let matchedPill = null;
        catPills.forEach(function (pill) {
            const isActive = pill.dataset.category === active;
            pill.classList.toggle('is-active', isActive);
            pill.setAttribute('aria-selected', isActive ? 'true' : 'false');
            if (isActive) {
                matchedPill = pill;
            }
        });

        if (matchedPill) {
            scrollFilterRailToPill(matchedPill);
        }
    }

    let scrollSpyTick = false;
    window.addEventListener(
        'scroll',
        function () {
            if (scrollSpyTick) return;
            scrollSpyTick = true;
            window.requestAnimationFrame(function () {
                scrollSpyTick = false;
                syncFilterPillsToScroll();
            });
        },
        { passive: true }
    );

    window.addEventListener('resize', function () {
        syncFilterPillsToScroll();
    });

    function scrollFilterRailToPill(pill) {
        const rail = pill.closest('.filter-rail');
        if (!rail) return;
        const railRect = rail.getBoundingClientRect();
        const pillRect = pill.getBoundingClientRect();
        const nextLeft =
            rail.scrollLeft +
            (pillRect.left - railRect.left) -
            railRect.width / 2 +
            pillRect.width / 2;
        const maxScroll = Math.max(0, rail.scrollWidth - rail.clientWidth);
        rail.scrollTo({
            left: Math.max(0, Math.min(nextLeft, maxScroll)),
            behavior: 'smooth',
        });
    }

    catPills.forEach(function (pill) {
        pill.addEventListener('click', function () {
            suppressScrollSpyUntil = Date.now() + 750;

            catPills.forEach(function (p) {
                p.classList.remove('is-active');
                p.setAttribute('aria-selected', 'false');
            });
            this.classList.add('is-active');
            this.setAttribute('aria-selected', 'true');

            scrollFilterRailToPill(this);

            const targetId = this.dataset.target || '';
            if (targetId) {
                const targetEl = document.getElementById(targetId);
                if (targetEl) {
                    targetEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
            }
        });
    });

    applyFilter();

    function copyUrlViaExecCommand(text) {
        const ta = document.createElement('textarea');
        ta.value = text;
        ta.setAttribute('readonly', '');
        ta.style.cssText = 'position:fixed;left:-9999px;top:0';
        document.body.appendChild(ta);
        ta.select();
        ta.setSelectionRange(0, text.length);
        let ok = false;
        try {
            ok = document.execCommand('copy');
        } catch (e) {
            ok = false;
        }
        document.body.removeChild(ta);
        return ok;
    }

    async function copyMenuLink(url) {
        if (navigator.clipboard && window.isSecureContext) {
            try {
                await navigator.clipboard.writeText(url);
                return true;
            } catch (e) {
                /* fall through */
            }
        }
        return copyUrlViaExecCommand(url);
    }

    const shareSheet = document.getElementById('shareSheet');
    const shareSheetBackdrop = document.getElementById('shareSheetBackdrop');
    const shareSheetClose = document.getElementById('shareSheetClose');
    const shareSheetCopied = document.getElementById('shareSheetCopied');
    const shareLinkWhatsApp = document.getElementById('shareLinkWhatsApp');
    const shareLinkFacebook = document.getElementById('shareLinkFacebook');
    const shareLinkX = document.getElementById('shareLinkX');
    const shareLinkTelegram = document.getElementById('shareLinkTelegram');
    const shareLinkEmail = document.getElementById('shareLinkEmail');
    const shareNativeBtn = document.getElementById('shareNativeBtn');
    const shareCopyAgain = document.getElementById('shareCopyAgain');
    const shareBtn = document.getElementById('shareBtn');

    function closeShareSheet() {
        if (!shareSheet) return;
        shareSheet.classList.remove('open');
        shareSheet.setAttribute('aria-hidden', 'true');
        document.body.style.overflow = '';
    }

    function openShareSheet(wasCopied) {
        if (!shareSheet || !shareLinkWhatsApp) return;
        const url = window.location.href;
        const title = document.title;
        const encUrl = encodeURIComponent(url);
        const encTitle = encodeURIComponent(title);
        const msg = encodeURIComponent(title + '\n' + url);

        shareLinkWhatsApp.href = 'https://wa.me/?text=' + msg;
        shareLinkFacebook.href = 'https://www.facebook.com/sharer/sharer.php?u=' + encUrl;
        shareLinkX.href = 'https://twitter.com/intent/tweet?url=' + encUrl + '&text=' + encTitle;
        shareLinkTelegram.href = 'https://t.me/share/url?url=' + encUrl + '&text=' + encTitle;
        shareLinkEmail.href =
            'mailto:?subject=' + encTitle + '&body=' + encodeURIComponent(url + '\n\n' + title);

        if (shareSheetCopied) {
            if (wasCopied) {
                shareSheetCopied.textContent = '✓ Copied! Link is in your clipboard.';
                shareSheetCopied.classList.remove('share-sheet__copied--warn');
            } else {
                shareSheetCopied.textContent =
                    'Could not copy automatically — choose an app below or tap “Copy link again”.';
                shareSheetCopied.classList.add('share-sheet__copied--warn');
            }
        }

        if (shareNativeBtn) {
            shareNativeBtn.style.display = typeof navigator.share === 'function' ? 'block' : 'none';
        }

        shareSheet.classList.add('open');
        shareSheet.setAttribute('aria-hidden', 'false');
        document.body.style.overflow = 'hidden';
    }

    if (shareBtn && shareSheet) {
        shareBtn.addEventListener('click', async function (event) {
            event.preventDefault();
            const copied = await copyMenuLink(window.location.href);
            openShareSheet(copied);
        });
    }

    if (shareSheetBackdrop) {
        shareSheetBackdrop.addEventListener('click', closeShareSheet);
    }

    if (shareSheetClose) {
        shareSheetClose.addEventListener('click', closeShareSheet);
    }

    if (shareCopyAgain) {
        shareCopyAgain.addEventListener('click', async function () {
            const ok = await copyMenuLink(window.location.href);
            if (shareSheetCopied) {
                shareSheetCopied.textContent = ok
                    ? '✓ Copied again! Link is in your clipboard.'
                    : 'Copy failed — open a link above or copy the URL from the address bar.';
                shareSheetCopied.classList.toggle('share-sheet__copied--warn', !ok);
                shareSheetCopied.classList.add('share-sheet__copied--pulse');
                setTimeout(function () {
                    shareSheetCopied.classList.remove('share-sheet__copied--pulse');
                }, 400);
            }
        });
    }

    if (shareNativeBtn) {
        shareNativeBtn.addEventListener('click', async function () {
            if (typeof navigator.share !== 'function') return;
            try {
                await navigator.share({
                    title: document.title,
                    text: document.title,
                    url: window.location.href,
                });
                closeShareSheet();
            } catch (e) {
                if (e && e.name !== 'AbortError') {
                    /* ignore */
                }
            }
        });
    }

    const itemModal = document.getElementById('itemModal');
    const itemModalImg = document.getElementById('itemModalImg');
    const itemModalTitle = document.getElementById('itemModalTitle');
    const itemModalDesc = document.getElementById('itemModalDesc');
    const itemModalPrice = document.getElementById('itemModalPrice');
    const itemModalClose = document.getElementById('itemModalClose');
    const itemModalBack = document.getElementById('itemModalBack');
    const itemModalStage = document.getElementById('itemModalStage');
    const itemCards = document.querySelectorAll('.item-card');
    const ITEM_MODAL_STATE_KEY = 'menuItemModal';

    function closeItemModalUiOnly() {
        if (!itemModal) return;
        itemModal.classList.remove('open');
        itemModal.setAttribute('aria-hidden', 'true');
        if (itemModalImg) {
            itemModalImg.src = '';
            itemModalImg.removeAttribute('src');
        }
    }

    function closeItemModalWithHistory() {
        if (history.state && history.state[ITEM_MODAL_STATE_KEY]) {
            history.back();
        } else {
            closeItemModalUiOnly();
        }
    }

    function openItemModal(card) {
        if (!itemModal || !itemModalImg || !itemModalTitle || !itemModalDesc || !itemModalPrice) return;
        const img = card.dataset.itemImage || '';
        const name = card.dataset.name || '';
        const desc = (card.dataset.description || '').trim();
        const priceDisplay = card.dataset.priceDisplay || '0.00 ETB';

        itemModalImg.src = img;
        itemModalImg.alt = name;
        itemModalTitle.textContent = name;
        itemModalDesc.textContent = desc;
        itemModalDesc.hidden = !desc;
        itemModalPrice.textContent = priceDisplay;

        itemModal.classList.add('open');
        itemModal.setAttribute('aria-hidden', 'false');
        history.pushState({ [ITEM_MODAL_STATE_KEY]: true }, '', window.location.href);
    }

    window.addEventListener('popstate', function () {
        if (itemModal && itemModal.classList.contains('open')) {
            closeItemModalUiOnly();
        }
    });

    itemCards.forEach(function (card) {
        card.addEventListener('click', function () {
            openItemModal(this);
        });
        card.addEventListener('keydown', function (event) {
            if (event.key === 'Enter' || event.key === ' ') {
                event.preventDefault();
                openItemModal(this);
            }
        });
    });

    if (itemModalClose) {
        itemModalClose.addEventListener('click', function (event) {
            event.stopPropagation();
            closeItemModalWithHistory();
        });
    }

    if (itemModalBack) {
        itemModalBack.addEventListener('click', function (event) {
            event.stopPropagation();
            closeItemModalWithHistory();
        });
    }

    if (itemModalStage) {
        itemModalStage.addEventListener('click', function (event) {
            if (event.target === itemModalStage) {
                closeItemModalWithHistory();
            }
        });
    }

    document.addEventListener('keydown', function (event) {
        if (event.key !== 'Escape') return;
        if (shareSheet && shareSheet.classList.contains('open')) {
            event.preventDefault();
            closeShareSheet();
            return;
        }
        if (itemModal && itemModal.classList.contains('open')) {
            event.preventDefault();
            closeItemModalWithHistory();
        }
    });
});
